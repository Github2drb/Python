import pyodbc
import matplotlib.pyplot as plt

# Function to connect to SQL Server and execute query
def fetch_data(server, database, username, password):
    # Establish connection
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        f'SERVER={server};'
        f'DATABASE={database};'
        f'UID={username};'
        f'PWD={password}'
    )

    # Create a cursor object using the connection
    cursor = conn.cursor()

    # Query to count occurrences of each modelno
    query = '''
    SELECT sModel, COUNT(*) as count
    FROM [dbo].[Box_Label_Log]where cast(sPrint_date as date)=cast(getdate() as date)
    GROUP BY sModel
    '''

    # Execute the query
    cursor.execute(query)

    # Fetch all rows
    rows = cursor.fetchall()

    # Close cursor and connection
    cursor.close()
    conn.close()

    return rows

# Function to create pie chart
def create_pie_chart(data):
    labels = [row[0] for row in data]   # accessing first column (modelno)
    counts = [row[1] for row in data]   # accessing second column (count)

    # Calculate percentages
    total = sum(counts)
    percentages = [(count / total) * 100 for count in counts]

    # Create labels with modelno, count, and percentage
    labels_with_info = [f'{label}: {count} ({percentage:.1f}%)' for label, count, percentage in zip(labels, counts, percentages)]

    # Create pie chart with custom labels
    plt.figure(figsize=(4, 3))
    patches, texts, autotexts = plt.pie(counts, labels=labels_with_info, autopct='%1.1f%%', startangle=140)
    
    # Add total count as a title
    plt.title(f'Total Count: {total}')

    # Adjust label properties to avoid overlapping
    for text, autotext in zip(texts, autotexts):
        text.set_fontsize(10)
        autotext.set_fontsize(10)
    
    plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    plt.show()

# Replace with your SQL Server connection details
server = 'DESKTOP-U4DC4J2'
database = 'E2223_158'
username = 'sa'
password = '1234'

# Fetch data from SQL Server
data = fetch_data(server, database, username, password)

# Create pie chart
create_pie_chart(data)
